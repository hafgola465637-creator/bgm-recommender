# merge_lyrics.py
import json
import os

# 要合并的文件列表（根据你实际有的文件调整）
files = ["lyrics1.json","lyrics2.json","lyrics3.json","lyrics4.json","lyrics5.json"]
all_songs = []

for file in files:
    if os.path.exists(file):
        print(f"正在读取 {file}...")
        with open(file, "r", encoding="utf-8") as f:
            data = json.load(f)
            # 如果文件是单个对象（不是数组），包装成列表
            if isinstance(data, dict):
                data = [data]
            elif not isinstance(data, list):
                print(f"⚠️ 跳过无效格式: {file}")
                continue

            for song in data:
                # 转换字段
                title = song.get("name", "").strip()
                artist = song.get("singer", "").strip()
                lyric_list = song.get("lyric", [])
                
                # 合并歌词列表为一个字符串
                lyrics = "\n".join(str(line) for line in lyric_list if line is not None)

                # 简单判断语言：只要包含中文字符就标为 zh，否则 en
                language = "zh" if any('\u4e00' <= char <= '\u9fff' for char in lyrics) else "en"

                # 只保留非空歌曲
                if title and artist and lyrics.strip():
                    all_songs.append({
                        "title": title,
                        "artist": artist,
                        "language": language,
                        "lyrics": lyrics
                    })
    else:
        print(f"⚠️ 文件不存在: {file}")

# 去重：用 (title, artist) 作为唯一标识
seen = set()
unique_songs = []
for song in all_songs:
    key = (song["title"], song["artist"])
    if key not in seen:
        seen.add(key)
        unique_songs.append(song)

# 保存为 bgm_library.json
with open("bgm_library.json", "w", encoding="utf-8") as f:
    json.dump(unique_songs, f, ensure_ascii=False, indent=2)

print(f"\n✅ 合并完成！共 {len(unique_songs)} 首不重复的歌曲")
print("新歌单已保存为：bgm_library.json")